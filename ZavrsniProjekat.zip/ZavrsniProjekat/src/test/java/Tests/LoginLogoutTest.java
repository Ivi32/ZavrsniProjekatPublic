package Tests;

import Base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginLogoutTest extends BaseTest {

    @BeforeMethod
    public void pageSetUp(){
        driver.navigate().to("https://www.saucedemo.com/");
    }

    @Test
    public void verifyThatUserCanLogin() throws InterruptedException {
        String validUsername= excelReader.getStringData("List1", 5, 0);
        String validPassword = excelReader.getStringData("List1", 5, 1);
        loginPage.inputUsername(validUsername);
        loginPage.inputPassword(validPassword);
        loginPage.clickOnLoginButton();

        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");

        inventoryPage.clickOnTheSidebarMenu();
        Thread.sleep(2000);
        Assert.assertTrue(inventoryPage.logout.isDisplayed());
    }

    @Test
    public void verifyThatUserCannotLogin(){
        String validUsername= excelReader.getStringData("List1", 5, 2);
        String validPassword = excelReader.getStringData("List1", 5, 1);
        loginPage.inputUsername(validUsername);
        loginPage.inputPassword(validPassword);
        loginPage.clickOnLoginButton();

        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/");
        Assert.assertTrue(loginPage.loginErrorMessage.isDisplayed());
    }

    @Test
    public void verifyThatUserCanLogout() throws InterruptedException {
        String validUsername= excelReader.getStringData("List1", 5, 0);
        String validPassword = excelReader.getStringData("List1", 5, 1);
        loginPage.inputUsername(validUsername);
        loginPage.inputPassword(validPassword);
        loginPage.clickOnLoginButton();

        inventoryPage.clickOnTheSidebarMenu();
        Thread.sleep(2000);
        inventoryPage.clickOnLogout();

        Assert.assertTrue(loginPage.loginButton.isDisplayed());
        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/");
    }


}
