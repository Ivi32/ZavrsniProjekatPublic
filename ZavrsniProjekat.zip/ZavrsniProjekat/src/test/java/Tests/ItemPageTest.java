package Tests;

import Base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ItemPageTest extends BaseTest {

    @BeforeMethod
    public void pageSetUp(){
        driver.navigate().to("https://www.saucedemo.com/");
        String validUsername= excelReader.getStringData("List1", 5, 0);
        String validPassword = excelReader.getStringData("List1", 5, 1);
        loginPage.inputUsername(validUsername);
        loginPage.inputPassword(validPassword);
        loginPage.clickOnLoginButton();
    }

    @Test
    public void verifyItemAddRemove() throws InterruptedException {
        int x = 1;
        for (int i = 0; i < inventoryPage.listOfItems.size(); i++) {
            inventoryPage.listOfItems.get(i).findElement(By.className("inventory_item_img")).click();
            //Thread.sleep(2000);
            itemPage.clickOnAddToCartButton();
            Assert.assertEquals(String.valueOf(itemPage.shoppingCartIcon.getText()), String.valueOf(x));
            Assert.assertTrue(itemPage.removeButton.isDisplayed());

            itemPage.clickOnRemoveButton();
            Assert.assertTrue(itemPage.addToCartButton.isDisplayed());
            Assert.assertEquals(String.valueOf(itemPage.shoppingCartIcon.getText()), "");

            itemPage.clickOnBackToProducts();
            Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
        }
    }


}
